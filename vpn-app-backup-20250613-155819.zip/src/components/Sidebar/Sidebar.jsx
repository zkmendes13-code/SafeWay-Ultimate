import React, { useState } from 'react';
import PricingPage from '../PricingPage/PricingPage';

const Sidebar = ({ 
  isOpen, 
  onClose, 
  onUpdate, 
  onShowLogs, 
  onCheckUser, 
  onBatteryOptimization,
  connectionState, // Agregamos el estado de conexión
  userData // Agregamos los datos del usuario
}) => {
  const [isPricingModalOpen, setIsPricingModalOpen] = useState(false);

  const menuItems = [
    { icon: '👑', text: 'Comprar Acceso', action: () => {
      console.log('🛒 Abrir modal de precios');
      setIsPricingModalOpen(true);
    }, special: true },
  ];

  const actionItems = [
    { icon: '👤', text: 'Verificar Usuario', action: onCheckUser },
    { icon: '📋', text: 'Ver Registros', action: onShowLogs },
    { icon: '🔄', text: 'Actualizar', action: onUpdate },
    { icon: '🔋', text: 'Optimizar Batería', action: onBatteryOptimization },
  ];

  const handleItemClick = (action) => {
    if (action) {
      action();
    }
    onClose();
  };

  return (
    <>
      {/* Overlay simplificado para mejor rendimiento */}
      <div 
        className={`fixed inset-0 bg-black/60 z-40 transition-opacity duration-200 ${
          isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`} 
        onClick={onClose}
      />
      
      {/* Sidebar optimizado - menos efectos complejos */}
      <div className={`fixed top-0 left-0 bottom-0 w-72 sm:w-80 max-w-[85vw] bg-vpn-bg-modal/95 border-r border-primary-500/20 z-50 transition-transform duration-200 ease-out shadow-lg ${
        isOpen ? 'transform-none' : '-translate-x-full'
      }`}>
        
        {/* Container principal con safe areas */}
        <div className="h-full flex flex-col safe-area-top safe-area-bottom safe-area-left">
          
          {/* Header simplificado */}
          <div className="flex-shrink-0 flex items-center justify-between p-3 sm:p-4 border-b border-primary-500/20 bg-primary-500/5">
            <div className="flex items-center space-x-3 min-w-0 flex-1">
              <div className="w-8 h-8 sm:w-9 sm:h-9 bg-primary-500/80 rounded-lg flex items-center justify-center">
                <span className="text-white text-lg">🛡️</span>
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm sm:text-base font-bold text-white truncate">
                  TÚNEL INFINITO
                </div>
                <div className="text-xs text-vpn-gray-text">
                  VPN Segura
                </div>
              </div>
            </div>
            <button 
              className="flex items-center justify-center w-8 h-8 sm:w-9 sm:h-9 rounded-lg bg-white/10 hover:bg-primary-500/20 transition-colors duration-200 text-white flex-shrink-0 ml-2"
              onClick={onClose}
            >
              <i className="fas fa-times text-sm"></i>
            </button>
          </div>
          
          {/* Content optimizado */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden sidebar-scrollbar">
            <div className="p-3 sm:p-4">
              
              {/* Menu principal simplificado */}
              <div className="space-y-2 mb-6">
                <div className="text-xs font-semibold text-vpn-gray-text uppercase tracking-wider mb-3 px-2">
                  👑 Premium
                </div>
                {menuItems.map((item, index) => (
                  <button 
                    key={index}
                    className={`w-full flex items-center space-x-3 px-4 py-4 rounded-xl transition-all duration-200 min-h-[52px] ${
                      item.special 
                        ? 'bg-gradient-to-r from-primary-500 to-accent-500 hover:from-vpn-purple-dark hover:to-primary-500 text-white shadow-lg hover:shadow-primary-500/20 border border-primary-500/30'
                        : 'bg-white/5 hover:bg-primary-500/10 text-white'
                    }`}
                    onClick={() => handleItemClick(item.action)}
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      item.special 
                        ? 'bg-white/20 backdrop-blur-sm border border-white/10'
                        : 'bg-primary-500/20'
                    }`}>
                      <span className="text-base">{item.icon}</span>
                    </div>
                    <span className={`font-medium text-base truncate ${
                      item.special ? 'font-bold' : ''
                    }`}>
                      {item.text}
                    </span>
                    {item.special && (
                      <i className="fas fa-external-link-alt text-xs text-white/80 ml-auto"></i>
                    )}
                  </button>
                ))}
              </div>
              
              {/* Separador simple */}
              <div className="h-px bg-primary-500/30 my-6"></div>
              
              {/* Sección de acciones simplificada */}
              <div className="space-y-1 mb-6">
                <div className="text-xs font-semibold text-vpn-gray-text uppercase tracking-wider mb-3 px-2">
                  ⚡ Acciones
                </div>
                {actionItems.map((item, index) => (
                  <button 
                    key={`action-${index}`}
                    className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg bg-transparent hover:bg-primary-500/10 text-vpn-gray-text hover:text-white transition-all duration-150 min-h-[40px]"
                    onClick={() => handleItemClick(item.action)}
                  >
                    <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm">{item.icon}</span>
                    </div>
                    <span className="font-medium text-sm truncate">
                      {item.text}
                    </span>
                  </button>
                ))}
              </div>
              
              {/* Información de estado simplificada */}
              <div className="space-y-3 mb-4">
                <div className="text-xs font-semibold text-vpn-gray-text uppercase tracking-wider mb-3 px-2">
                  📊 Estado
                </div>
                
                {/* Estado VPN simple */}
                <div className="bg-white/5 rounded-lg p-4 border border-primary-500/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        connectionState === 'CONNECTED' ? 'bg-vpn-green-success/20' :
                        connectionState === 'CONNECTING' ? 'bg-primary-500/20' :
                        'bg-vpn-red-error/20'
                      }`}>
                        <span className="text-lg">
                          {connectionState === 'CONNECTED' ? '🟢' :
                           connectionState === 'CONNECTING' ? '🟡' :
                           '🔴'}
                        </span>
                      </div>
                      <div>
                        <div className="text-xs text-vpn-gray-text mb-1">Estado VPN</div>
                        <div className={`text-sm font-bold transition-all duration-300 ${
                          connectionState === 'CONNECTED' ? 'text-vpn-green-success' :
                          connectionState === 'CONNECTING' ? 'text-accent-500' :
                          'text-vpn-red-error'
                        }`}>
                          {connectionState === 'CONNECTED' ? 'Conectado' :
                           connectionState === 'CONNECTING' ? 'Conectando...' :
                           'Desconectado'}
                        </div>
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full transition-all duration-500 ${
                      connectionState === 'CONNECTED' ? 'bg-vpn-green-success animate-pulse' :
                      connectionState === 'CONNECTING' ? 'bg-accent-500 animate-pulse' :
                      'bg-vpn-red-error'
                    }`}></div>
                  </div>
                </div>
                
                {/* Conexiones activas con glassmorphism */}
                <div className="bg-gradient-to-r from-white/5 to-white/10 backdrop-blur-sm rounded-xl p-4 border border-primary-500/20 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary-500/20 border border-primary-500/40 rounded-xl flex items-center justify-center">
                        <span className="text-lg">👥</span>
                      </div>
                      <div>
                        <div className="text-xs text-vpn-gray-text mb-1">Conexiones</div>
                        <div className="text-sm text-white font-bold">
                          {userData ? 
                            `${userData.count_connections || 0} / ${userData.limit_connections || 0}` : 
                            '0 / 0'
                          }
                        </div>
                      </div>
                    </div>
                    <div className="flex space-x-1">
                      {Array.from({ length: userData?.limit_connections || 5 }).map((_, i) => (
                        <div 
                          key={i}
                          className={`w-2 h-2 rounded-full transition-all duration-300 ${
                            i < (userData?.count_connections || 0) ? 'bg-accent-500' : 'bg-white/20'
                          }`}
                        ></div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Padding extra para asegurar scroll */}
              <div className="h-4"></div>
            </div>
          </div>
          
          {/* Footer simple */}
          <div className="flex-shrink-0 p-3 sm:p-4 border-t border-primary-500/20 bg-primary-500/5">
            <button 
              className="w-full flex items-center space-x-3 px-3 py-3 rounded-lg bg-vpn-red-error/10 hover:bg-vpn-red-error/20 text-vpn-red-error transition-all duration-150 min-h-[44px]"
              onClick={onClose}
            >
              <div className="w-8 h-8 bg-vpn-red-error/20 rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-sm">🚪</span>
              </div>
              <span className="font-medium text-sm sm:text-base">
                Cerrar
              </span>
            </button>
          </div>
          
        </div>
      </div>

      {/* Página de Precios */}
      <PricingPage
        isOpen={isPricingModalOpen}
        onClose={() => setIsPricingModalOpen(false)}
      />
    </>
  );
};

export default Sidebar;
